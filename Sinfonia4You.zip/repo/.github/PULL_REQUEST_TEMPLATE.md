## Descrizione

Breve descrizione della modifica e del problema risolto.

## Tipo di modifica

- [ ] Nuova funzionalita
- [ ] Correzione di bug
- [ ] Refactor / manutenzione
- [ ] Documentazione

## Ambito

- [ ] App iOS
- [ ] App watchOS
- [ ] Entrambe

## Verifiche

- [ ] Il progetto compila senza warning nuovi
- [ ] I test esistenti passano
- [ ] Sono stati aggiunti test dove sensato
- [ ] Nessun segreto, IP o credenziale nel diff
- [ ] Testato su simulatore iPhone
- [ ] Testato su simulatore Apple Watch (se applicabile)

## Screenshot / video

Se la modifica tocca l'interfaccia, allega una prova visiva.
